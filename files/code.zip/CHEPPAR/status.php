

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trans Status</title>
</head>
<!-- Favicons -->
<link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">
  <link rel="stylesheet" href="./assets/css/success.css">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
<body>
<div class="container d-flex justify-content-center">
	<div class="card mt-5 p-3">
		<div class="media">
  			<img src="https://imgur.com/3UmlFEf.png" class="mr-3">
  			<div class="media-body">
    			<h6 class="mt-2 mb-0">Transaction Initiated </h6>
<?php
//Initiate the stk push

if(isset($_POST['submit'])){

  $invoice = $_POST['invoice'];
  $amount = $_POST['amount']; //Amount to transact 
  $phone = $_POST['phone']; // Phone number paying
  
  $Account_no = 'COMRADE MARKET'; // Enter account number optional
  $url = 'https://tinypesa.com/api/v1/express/initialize';
  $data = array(
      'amount' => $amount,
      'msisdn' => $phone,
      'account_no'=>$Account_no
  );
  $headers = array(
      'Content-Type: application/x-www-form-urlencoded',
      'ApiKey: Bo1HwSJ8xd3' // Replace with your api key
   );
  $info = http_build_query($data);
  
  $curl = curl_init();
  curl_setopt($curl, CURLOPT_URL, $url);
  curl_setopt($curl, CURLOPT_POST, true);
  curl_setopt($curl, CURLOPT_POSTFIELDS, $info);
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
  $resp = curl_exec($curl);
  $msg_resp = json_decode($resp);
  
  
  if ($msg_resp ->success == 'true') {
      echo "<h5>WAIT FOR  STK POP UP🔥</h5>";
    } else {
      echo "Transaction Failed";
     
    }

//Get Heroku ClearDB connection information
$cleardb_url = parse_url(getenv("CLEARDB_DATABASE_URL"));
$cleardb_server = $cleardb_url["host"];
$cleardb_username = $cleardb_url["user"];
$cleardb_password = $cleardb_url["pass"];
$cleardb_db = substr($cleardb_url["path"],1);
$active_group = 'default';
$query_builder = TRUE;
// Connect to DB
$conn = mysqli_connect($cleardb_server, $cleardb_username, $cleardb_password, $cleardb_db);
//Store Invoice number in a Temporary DataBase
$sql = "INSERT INTO temp_db(invoice)VALUE('$invoice')";
 

if ($conn->query($sql) === TRUE) {
echo "<h5>invoice saved 👑</h5>";
} else {
echo "Error: " . $sql . "<br>" . $conn->error;
}


}


?>
<a href="./index.php">
<small class="text"> ⬅ Back Home</small>
</a>
  			</div>
		</div>
	</div>
</div>
</body>
</html>