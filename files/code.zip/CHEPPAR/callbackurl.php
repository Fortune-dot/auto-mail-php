<?php
header("Content-Type: application/json");

$stkCallbackResponse = file_get_contents('php://input');
$logFile = "stkTinypesaResponse.json";
$log = fopen($logFile, "a");
fwrite($log, $stkCallbackResponse);
fclose($log);

$callbackContent = json_decode($stkCallbackResponse);

$ResultCode = $callbackContent->Body->stkCallback->ResultCode;
$CheckoutRequestID = $callbackContent->Body->stkCallback->CheckoutRequestID;
$Amount = $callbackContent->Body->stkCallback->CallbackMetadata->Item[0]->Value;
$MpesaReceiptNumber = $callbackContent->Body->stkCallback->CallbackMetadata->Item[1]->Value;
$PhoneNumber = $callbackContent->Body->stkCallback->CallbackMetadata->Item[4]->Value;

if ($ResultCode == 0) {

    //Get Heroku ClearDB connection information
    $cleardb_url = parse_url(getenv("CLEARDB_DATABASE_URL"));
    $cleardb_server = $cleardb_url["host"];
    $cleardb_username = $cleardb_url["user"];
    $cleardb_password = $cleardb_url["pass"];
    $cleardb_db = substr($cleardb_url["path"],1);
    $active_group = 'default';
    $query_builder = TRUE;
    // Connect to DB
    $conn = mysqli_connect($cleardb_server, $cleardb_username, $cleardb_password, $cleardb_db);
    $sql = "SELECT * FROM temp_db";
     
     $result = $conn->query($sql);
       
     if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
         $invoice = $row["invoice"];              
        }
     } else {
        printf('No record found.<br />');
     }

    // Check connection
    if ($conn->connect_error) {
        die("<h1>Connection failed:</h1> " . $conn->connect_error);
    }
   else{

      
    $insert = $conn->query("INSERT INTO tinypesa(CheckoutRequestID,invoice,ResultCode,amount,MpesaReceiptNumber,PhoneNumber) VALUES ('$CheckoutRequestID','$invoice','$ResultCode','$Amount','$MpesaReceiptNumber','$PhoneNumber')");
      if($conn->query == TRUE ){
          echo"New record created";
      } else{
          echo"Error:" .$conn->error;
      }

    $purge = $conn->query("DELETE * FROM temp_db");
    
    if($conn->query == TRUE ){
        echo"DB purged💀";
    } else{
        echo"Error:" .$conn->error;
    }
      
    $conn = null;
}
}